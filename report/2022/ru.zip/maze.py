import sys
import PIL
import operator
import math


# Node类，代表迷宫节点，元组（i,j）；state：是否为路线，parent：先前节点，action:上下左右
class Node():

    def __init__(self, state, parent, action):
        self.state = state
        self.parent = parent
        self.action = action


# 堆栈，后进先出
class StackFrontier():
    def __init__(self):  # 初始化堆栈，列表格式
        self.frontier = []

    def add(self, node):  # 堆栈添加成员
        self.frontier.append(node)

    def contains_state(self, state):  # 判断某一状态state在堆栈内是否存在
        return any(node.state == state for node in self.frontier)

    def empty(self):  # 判断堆栈是否为空
        return len(self.frontier) == 0

    def remove(self):  # 移除操作，从队尾移除，返回移除的node
        if self.empty():
            raise Exception("empty frontier")
        else:
            node = self.frontier[-1]
            self.frontier = self.frontier[:-1]
            return node


# 队列，先进先出
class QueueFrontier(StackFrontier):

    def remove(self):  # 队列与堆栈唯一不同的一点是，移除成员时从队首移除
        if self.empty():
            raise Exception("empty frontier")
        else:
            node = self.frontier[0]
            self.frontier = self.frontier[1:]
            return node


class Maze():  # 迷宫类

    def __init__(self, filename):

        # 读取迷宫文件
        with open(filename) as f:
            contents = f.read()

        # 确认迷宫的合法性，迷宫至少要有一个起点和一个终点
        if contents.count("A") != 1:
            raise Exception("maze must have exactly one start point")
        if contents.count("B") != 1:
            raise Exception("maze must have exactly one goal")

        # 得到迷宫的高度和宽度
        contents = contents.splitlines()
        self.height = len(contents)  # 迷宫高度
        self.width = max(len(line) for line in contents)  # 迷宫宽度

        # 扫描迷宫
        self.walls = []
        for i in range(self.height):
            row = []
            for j in range(self.width):  # 遍历迷宫的每一格
                try:
                    if contents[i][j] == "A":  # 找到迷宫的起点
                        self.start = (i, j)
                        row.append(False)
                    elif contents[i][j] == "B":  # 找到迷宫的终点
                        self.goal = (i, j)
                        row.append(False)
                    elif contents[i][j] == " ":  # 迷宫的空位置
                        row.append(False)
                    else:
                        row.append(True)  # 迷宫的墙壁
                except IndexError:
                    row.append(False)
            self.walls.append(row)  # 将迷宫转化为布尔表

        self.solution = None

    def print(self):  # 用于打印迷宫，并在图上打印当前solution
        solution = self.solution[1] if self.solution is not None else None
        print()
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):
                if col:
                    print("█", end="")
                elif (i, j) == self.start:
                    print("A", end="")
                elif (i, j) == self.goal:
                    print("B", end="")
                elif solution is not None and (i, j) in solution:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
        print()

    def neighbors(self, state):  # 找到当前状态下所有的可行邻居
        row, col = state
        candidates = [
            ("up", (row - 1, col)),
            ("down", (row + 1, col)),
            ("left", (row, col - 1)),
            ("right", (row, col + 1))
        ]

        result = []
        for action, (r, c) in candidates:
            if 0 <= r < self.height and 0 <= c < self.width and not self.walls[r][c]:
                result.append((action, (r, c)))
        return result

    def findMinNode(self, frontier):  # 用于寻找启发函数最小的节点，启发式为：与起点的曼哈顿距离+与终点的曼哈顿距离
        NodeM = frontier[-1]
        for i in range(len(frontier)):
            node = frontier[i]
            if (abs(self.start[0] - node.state[0]) + abs(self.start[1] - node.state[1]) + abs(
                    self.goal[0] - node.state[0]) + abs(self.goal[1] - node.state[1]) < abs(
                self.start[0] - NodeM.state[0]) + abs(self.start[1] - NodeM.state[1]) + abs(
                self.goal[0] - NodeM.state[0]) + abs(self.goal[1] - NodeM.state[1])):
                NodeM = node
        return NodeM

    def solve_A_star(self):  # A*搜索
        """Finds a solution to maze, if one exists."""

        # Keep track of number of states explored
        self.num_explored = 0  # 已搜索的状态数目

        # Initialize frontier to just the starting position
        start = Node(state=self.start, parent=None, action=None)  # 设置初始节点，状态为{start,nome,none}
        frontier = StackFrontier()  # 初始化堆栈
        frontier.add(start)  # 将初始节点加入堆栈

        # Initialize an empty explored set
        self.explored = set()  # 已搜索的节点

        # Keep looping until solution found
        while True:

            # If nothing left in frontier, then no path
            if frontier.empty():  # 堆栈中无node表示无解
                raise Exception("no solution")

            # Choose a node from the frontier
            node = self.findMinNode(frontier.frontier)  # 移出启发函数最小的节点
            frontier.frontier.remove(node)
            self.num_explored += 1  # 探索的节点数+1

            # If node is the goal, then we have a solution
            if node.state == self.goal:  # 如果node为目标表明找到解
                actions = []
                cells = []
                while node.parent is not None:  # 逐一寻找parent
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()  # 对列表逆序排列
                cells.reverse()  # 对列表逆序排列
                self.solution = (actions, cells)
                return

            # Mark node as explored
            self.explored.add(node.state)  # 该节点已被探索

            # Add neighbors to frontier
            for action, state in self.neighbors(node.state):  # 遍历当前状态的所有邻居
                if not frontier.contains_state(state) and state not in self.explored:  # 堆栈中不包含该状态且未被探索
                    child = Node(state=state, parent=node, action=action)
                    frontier.add(child)

    def solve_Greedy(self):  # 贪婪搜索
        """Finds a solution to maze, if one exists."""

        # Keep track of number of states explored
        self.num_explored = 0  # 已搜索的状态数目

        # Initialize frontier to just the starting position
        start = Node(state=self.start, parent=None, action=None)  # 设置初始节点，状态为{start,nome,none}
        frontier = StackFrontier()  # 初始化堆栈
        frontier.add(start)  # 将初始节点加入堆栈

        # Initialize an empty explored set
        self.explored = set()  # 已搜索的节点

        # Keep looping until solution found
        while True:

            # If nothing left in frontier, then no path
            if frontier.empty():  # 堆栈中无node表示无解
                raise Exception("no solution")

            # Choose a node from the frontier
            node = frontier.remove()  # 移出堆栈顶node
            self.num_explored += 1  # 探索的节点数+1

            # If node is the goal, then we have a solution
            if node.state == self.goal:  # 如果node为目标表明找到解
                actions = []
                cells = []
                while node.parent is not None:  # 逐一寻找parent
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()  # 对列表逆序排列
                cells.reverse()  # 对列表逆序排列
                self.solution = (actions, cells)
                return

            # Mark node as explored
            self.explored.add(node.state)  # 该节点已被探索

            # Add neighbors to frontier
            choices = []  # 待入栈邻居列表
            for action, state in self.neighbors(node.state):  # 遍历当前状态的所有邻居
                if not frontier.contains_state(state) and state not in self.explored:  # 堆栈中不包含该状态且未被探索
                    child = Node(state=state, parent=node, action=action)
                    choices.append(child)
            # 将邻居根据曼哈顿距离由大到小排序
            for i in range(len(choices) - 1):
                for j in range(i + 1, len(choices)):
                    if abs(self.goal[0] - choices[i].state[0]) + abs(self.goal[1] - choices[i].state[1]) < abs(
                            self.goal[0] - choices[j].state[0]) + abs(self.goal[1] - choices[j].state[1]):
                        temp = choices[i]
                        choices[i] = choices[j]
                        choices[j] = temp
            # 将排序好的邻居顺序入栈
            for i in range(len(choices)):
                frontier.add(choices[i])  # 将搜索到的邻居加入堆栈

    def solve_DFS(self):  # 深度优先搜索
        """Finds a solution to maze, if one exists."""

        # Keep track of number of states explored
        self.num_explored = 0  # 已搜索的状态数目

        # Initialize frontier to just the starting position
        start = Node(state=self.start, parent=None, action=None)  # 设置初始节点，状态为{start,nome,none}
        frontier = StackFrontier()  # 初始化堆栈
        frontier.add(start)  # 将初始节点加入堆栈

        # Initialize an empty explored set
        self.explored = set()  # 已搜索的节点

        # Keep looping until solution found
        while True:

            # If nothing left in frontier, then no path
            if frontier.empty():  # 堆栈中无node表示无解
                raise Exception("no solution")

            # Choose a node from the frontier
            node = frontier.remove()  # 移出堆栈顶node
            self.num_explored += 1  # 探索的节点数+1

            # If node is the goal, then we have a solution
            if node.state == self.goal:  # 如果node为目标表明找到解
                actions = []
                cells = []
                while node.parent is not None:  # 逐一寻找parent
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()  # 对列表逆序排列
                cells.reverse()  # 对列表逆序排列
                self.solution = (actions, cells)
                return

            # Mark node as explored
            self.explored.add(node.state)  # 该节点已被探索

            # Add neighbors to frontier
            for action, state in self.neighbors(node.state):  # 遍历当前状态的所有邻居
                if not frontier.contains_state(state) and state not in self.explored:  # 堆栈中不包含该状态且未被探索
                    child = Node(state=state, parent=node, action=action)
                    frontier.add(child)

    def solve_BFS(self):  # 宽度优先搜索
        """Finds a solution to maze, if one exists."""

        # Keep track of number of states explored
        self.num_explored = 0  # 已搜索的状态数目

        # Initialize frontier to just the starting position
        start = Node(state=self.start, parent=None, action=None)  # 设置初始节点，状态为{start,nome,none}
        frontier = QueueFrontier()  # 初始化堆栈
        frontier.add(start)  # 将初始节点加入堆栈

        # Initialize an empty explored set
        self.explored = set()  # 已搜索的节点

        # Keep looping until solution found
        while True:

            # If nothing left in frontier, then no path
            if frontier.empty():  # 堆栈中无node表示无解
                raise Exception("no solution")

            # Choose a node from the frontier
            node = frontier.remove()  # 移出堆栈顶node
            self.num_explored += 1  # 探索的节点数+1

            # If node is the goal, then we have a solution
            if node.state == self.goal:  # 如果node为目标表明找到解
                actions = []
                cells = []
                while node.parent is not None:  # 逐一寻找parent
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()  # 对列表逆序排列
                cells.reverse()  # 对列表逆序排列
                self.solution = (actions, cells)
                return

            # Mark node as explored
            self.explored.add(node.state)  # 该节点已被探索

            # Add neighbors to frontier
            for action, state in self.neighbors(node.state):  # 遍历当前状态的所有邻居
                if not frontier.contains_state(state) and state not in self.explored:  # 堆栈中不包含该状态且未被探索
                    child = Node(state=state, parent=node, action=action)
                    frontier.add(child)

    def output_image(self, filename, show_solution=True, show_explored=False):  # 绘制迷宫
        from PIL import Image, ImageDraw
        cell_size = 50
        cell_border = 2

        # Create a blank canvas
        img = Image.new(
            "RGBA",
            (self.width * cell_size, self.height * cell_size),
            "black"
        )
        draw = ImageDraw.Draw(img)

        solution = self.solution[1] if self.solution is not None else None
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):

                # Walls
                if col:
                    fill = (40, 40, 40)

                # Start
                elif (i, j) == self.start:
                    fill = (255, 0, 0)

                # Goal
                elif (i, j) == self.goal:
                    fill = (0, 171, 28)

                # Solution
                elif solution is not None and show_solution and (i, j) in solution:
                    fill = (220, 235, 113)

                # Explored
                elif solution is not None and show_explored and (i, j) in self.explored:
                    fill = (212, 97, 85)

                # Empty cell
                else:
                    fill = (237, 240, 252)

                # Draw cell
                draw.rectangle(
                    ([(j * cell_size + cell_border, i * cell_size + cell_border),
                      ((j + 1) * cell_size - cell_border, (i + 1) * cell_size - cell_border)]),
                    fill=fill
                )

        img.save(filename)


# if len(sys.argv) != 2:
# sys.exit("Usage: python maze.py maze10.txt")

m = Maze("maze1.txt")
print("Maze:")
m.print()
print("Solving...")
m.solve_DFS()
print("States Explored:", m.num_explored)
print("Solution:")
m.print()
m.output_image("maze.png", show_explored=True)

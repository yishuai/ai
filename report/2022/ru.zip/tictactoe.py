"""
Tic Tac Toe Player
"""
import math

X = "X"
O = "O"
EMPTY = None
UUser = None


def initial_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def player(board):
    """
    Returns player who has the next turn on a board.
    """
    countX = 0
    countO = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] == 'X':
                countX = countX + 1
            if board[i][j] == 'O':
                countO = countO + 1
    if countX == countO:
        return X
    else:
        return O


def getUser(user):
    global UUser
    UUser = user
    return True


def actions(board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """
    actionSet = []
    for i in range(3):
        for j in range(3):
            if board[i][j] == EMPTY:
                actionSet.append((i, j))
    return actionSet


def result(board, action):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    newBoard = [[EMPTY, EMPTY, EMPTY],
                [EMPTY, EMPTY, EMPTY],
                [EMPTY, EMPTY, EMPTY]]
    for i in range(3):
        for j in range(3):
            newBoard[i][j] = board[i][j]

    if newBoard[action[0]][action[1]] != EMPTY:
        raise NotImplementedError
    else:
        if player(board) == X:
            newBoard[action[0]][action[1]] = X
        else:
            newBoard[action[0]][action[1]] = O
        return newBoard


def winner(board):
    """
    Returns the winner of the game, if there is one.
    """
    if ((board[0][0] == X) & (board[0][1] == X) & (board[0][2] == X)) | (
            (board[1][0] == X) & (board[1][1] == X) & (board[1][2] == X)) | (
            (board[2][0] == X) & (board[2][1] == X) & (board[2][2] == X)) | (
            (board[0][0] == X) & (board[1][1] == X) & (board[2][2] == X)) | (
            (board[0][2] == X) & (board[1][1] == X) & (board[2][0] == X)) | (
            (board[0][0] == X) & (board[1][0] == X) & (board[2][0] == X)) | (
            (board[0][1] == X) & (board[1][1] == X) & (board[2][1] == X)) | (
            (board[0][2] == X) & (board[1][2] == X) & (board[2][2] == X)):
        return X
    if ((board[0][0] == O) & (board[0][1] == O) & (board[0][2] == O)) | (
            (board[1][0] == O) & (board[1][1] == O) & (board[1][2] == O)) | (
            (board[2][0] == O) & (board[2][1] == O) & (board[2][2] == O)) | (
            (board[0][0] == O) & (board[1][1] == O) & (board[2][2] == O)) | (
            (board[0][2] == O) & (board[1][1] == O) & (board[2][0] == O)) | (
            (board[0][0] == O) & (board[1][0] == O) & (board[2][0] == O)) | (
            (board[0][1] == O) & (board[1][1] == O) & (board[2][1] == O)) | (
            (board[0][2] == O) & (board[1][2] == O) & (board[2][2] == O)):
        return O
    return None


def terminal(board):
    """
    Returns True if game is over, False otherwise.
    """
    win = winner(board)
    if (win == X) | (win == O):
        return True
    else:
        count = 0
        for i in range(3):
            for j in range(3):
                if board[i][j] == EMPTY:
                    count = count + 1
        if count != 0:
            return False
        else:
            return True


def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """
    Result = winner(board)
    if Result == X:
        return 1
    elif Result == O:
        return -1
    else:
        return 0


def empty(board):
    count = 0
    for i in range(3):
        for j in range(3):
            if board[i][j] != EMPTY:
                count = count + 1
    if count == 0:
        return True
    else:
        return False


def minimax(board):
    """
    Returns the optimal action for the current player on the board.
    """
    turn = player(board)
    Actions = actions(board)
    Action = Actions[0]
    if turn == X:
        if (UUser == O) & empty(board):
            return (1, 1)
        for action in Actions:
            if min_value(result(board, Action)) < min_value(result(board, action)):
                Action = action
        return Action
    else:
        for action in Actions:
            if max_value(result(board, Action)) > max_value(result(board, action)):
                Action = action
        return Action


def max_value(board):
    if terminal(board):
        return utility(board)
    v = -10000
    for action in actions(board):
        v1 = min_value(result(board, action))
        if v1 > v:
            v = v1
    return v


def min_value(board):
    if terminal(board):
        return utility(board)
    v = 10000
    for action in actions(board):
        v1 = max_value(result(board, action))
        if v1 < v:
            v = v1
    return v

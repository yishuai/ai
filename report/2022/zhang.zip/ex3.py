import pomegranate as pe
sun = pe.DiscreteDistribution({
 "umbrella": 0.2,
 "no umbrella": 0.8
})
rain = pe.DiscreteDistribution({
 "umbrella": 0.9,
 "no umbrella": 0.1
})
states = [sun, rain]
# Transition model
transitions = pe.numpy.array(
 [[0.8, 0.2], # Tomorrow's predictions if today = sun
 [0.3, 0.7]] # Tomorrow's predictions if today = rain
)
# Starting probabilities
starts = pe.numpy.array([0.5, 0.5])
# Create the model
model = pe.HiddenMarkovModel.from_matrix(
 transitions, states, starts,
 state_names=["sun", "rain"]
)
model.bake()

observations = [
 "umbrella",
 "umbrella",
 "no umbrella",
 "umbrella",
 "umbrella",
 "umbrella",
 "umbrella",
 "no umbrella",
 "no umbrella"
]
# Predict underlying states
predictions = model.predict(observations)
for prediction in predictions:
 print(model.states[prediction].name)